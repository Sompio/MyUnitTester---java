/**
 * Created by per-joelsompio on 11/11/16.
 */
public interface TestClass {
}
